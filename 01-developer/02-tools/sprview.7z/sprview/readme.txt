win10 预览 spr 或者 act 的工具，可以不用在 grf 里面一个个预览

Borf's SPR previewer

To install, just run "install.bat". To uninstall, hit "uninstall.bat"


after this, go to any directory with .spr files in them, rightclick, hit "view" and then "thumbnails" (on XP)

tested on:
	WinXP
	Vista (not recommended though)


This program was made with the help of http://greggman.com/pages/thumbplug_tga.htm


File can be downloaded from

www.borf.nl/sprview.rar



bought to you by the Excalibur Network