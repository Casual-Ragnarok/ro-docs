Downloaded from www.openkore.com

Compilation Instructions:

1) You need the Olly_Dbg plugin for PureBasic
2) Make sure to uncheck Create unicode executable in compile options