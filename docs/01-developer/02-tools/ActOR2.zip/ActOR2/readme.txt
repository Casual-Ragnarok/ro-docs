actOR is ACT file editor.
This program guarantees NOTHING. Please use at your own risk.
Please see help\index.html 

You may use this program for private use.
  Use the remodeled data (which against official data) only in the home.
  Don't distribute the remodeled data.
  Don't put the screenshot that used remodeled data on view to the general public.
  You must obey the law of each country about the others.

You can redistribute this archive.
But, if you want to distributor, you must have some knowledge. (especially ACT&SPR file)
Because,

"If there is a question about this program, please ask to distributor."


May 10, 2007
xqy@Moxi (This is not mail address)
