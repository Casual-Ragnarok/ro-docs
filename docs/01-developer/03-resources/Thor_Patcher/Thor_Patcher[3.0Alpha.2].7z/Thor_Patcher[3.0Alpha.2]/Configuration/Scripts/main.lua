--[[
Thor Patcher demo script.
]]
local json = require "dkjson.lua"

local config, pos, err = json.decode(thor.getData("config.json", true), 1, nil)


----------------------------------------------------------------------

local noticeBox = {}

----------------------------------------------------------------------

local progressbar = {}

----------------------------------------------------------------------

local startButton = {}

function startButton:OnClick()
	if not thor.execute(config.General.ClientEXE, config.General.ClientParameter) then
		print "Unable to launch client"
	end
	thor.quit()
end

function startButton:OnMouseEnter()

end

function startButton:OnMouseLeave()

end

----------------------------------------------------------------------

local closeButton = {}

function closeButton:OnClick()
	thor.quit()
end

----------------------------------------------------------------------

local label = {}


----------------------------------------------------------------------

local globalEvents = {}

function globalEvents:OnComplete()
	--startButton:click()
	if config.General.HideProgressBarWhenFinish then
		progressbar:setVisible(false)
	end
end

function globalEvents:OnStatus(message)
	label:setText(message)
end

function globalEvents:OnProgressDone(value)
	progressbar:setPartsComplete(value)
end

function globalEvents:OnProgressTotal(value)
	progressbar:setTotalParts(value)
end

function globalEvents:OnUILockBegin()
	closeButton:setEnable(false)
end

function globalEvents:OnUILockEnd()
	closeButton:setEnable(true)
end

----------------------------------------------------------------------

thor.setComponent("startButton", startButton)
thor.setComponent("closeButton", closeButton)
thor.setComponent("statusLabel", label)
thor.setComponent("news", noticeBox)
thor.setComponent("progressBar", progressbar)
thor.setGlobalEventHandler(globalEvents)