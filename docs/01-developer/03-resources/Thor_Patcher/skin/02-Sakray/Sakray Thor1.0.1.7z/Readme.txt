Sakray Thor is an Skin that allows your Thor Patcher to
look like the old style Sakray Patcher.