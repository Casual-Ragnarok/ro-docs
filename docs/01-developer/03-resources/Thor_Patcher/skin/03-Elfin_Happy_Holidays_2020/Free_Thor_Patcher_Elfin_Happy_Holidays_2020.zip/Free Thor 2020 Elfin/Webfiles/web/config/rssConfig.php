<?php
return array(
			
	//RSS
		'RSSnews'				=>	array(
			'News'				=>	'https://rathena.org/board/rss/3-support-topics-feed.xml/?member_id=61096&key=e2467f270485318499a20e11a7a0948c',
			'Event'				=>	'https://rathena.org/board/rss/1-latest-community-announcements.xml/?member_id=61096&key=e2467f270485318499a20e11a7a0948c',
			'Maintenance'		=>	'https://rathena.org/board/rss/3-support-topics-feed.xml/?member_id=61096&key=e2467f270485318499a20e11a7a0948c',
		),

		'RSStopics'				=>	array(
			'Topics'				=>	'https://rathena.org/board/rss/3-support-topics-feed.xml/?member_id=61096&key=e2467f270485318499a20e11a7a0948c',
		),

);
?>

